# BIN Atlas v1.1

BIN lookup, issuer search and Luhn practice. Flet (Python), builds to Android.

## Tabs
- **Lookup** - one or many BINs (comma separated). HandyAPI-style card: scheme, type, tier, Luhn, issuer, country, continent, dial code, currency. Save a BIN with a note.
- **Banks** - cascading filters like bincheck.io: Country > Brand > Bank > Type > Level, Search / Reset, CSV export, CSV import of public BIN lists.
- **Learn** - multi-number Luhn checker with step-by-step explanation (on-device, nothing stored, long numbers masked).
- **Saved** - saved BINs with notes (searchable) + history. Tap any row to open the full card in place.

## Data sources (automatic failover)
binlist.io -> HandyAPI -> binlist.net. If one is down, rate-limited or rejects a key, the next one answers.
With "Combine sources" on, a second source fills missing fields (type, tier, issuer).

## API keys
Never put keys in the code or the repo. Open the app > gear icon > paste:
- binlist.io key (bl_...)
- HandyAPI **publishable** key (PUB-...). The secret key (HAS-...) is refused on purpose.
Tap "Save & test" to check each source.

## Run / test / build
    pip install flet==0.28.3 requests
    python main.py
    python -m unittest test_engine test_ui_smoke -v
    flet build apk --project "BIN Atlas" --org com.binatlas

## Privacy
Only the first 6 digits of a BIN are sent or stored. The Luhn checker never stores or sends anything.
