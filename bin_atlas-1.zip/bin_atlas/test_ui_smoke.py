"""UI smoke test with a stub `flet` (no Flet install needed).
Clicks through every tab and action to catch NameErrors / wrong wiring.
It cannot check real Flet rendering - test the APK on a device for that."""
import os, sys, tempfile, types, unittest
from unittest import mock

HERE = os.path.dirname(os.path.abspath(__file__))
os.environ["FLET_APP_STORAGE_DATA"] = tempfile.mkdtemp()
sys.path.insert(0, HERE)


class Ctl:
    def __init__(self, *a, **kw):
        self.args = a
        self.__dict__.update(kw)
        self.controls = list(a[0]) if a and isinstance(a[0], list) else list(kw.get("controls", []) or [])
        self.value = kw.get("value", None)


def make_ft():
    ft = mock.MagicMock()
    for name in ("Container", "Column", "Row", "Text", "TextField", "Switch", "Dropdown", "Image",
                 "ProgressBar", "Icon", "IconButton", "TextButton", "SafeArea", "NavigationBar",
                 "NavigationBarDestination", "AlertDialog", "SnackBar", "FilePicker"):
        setattr(ft, name, Ctl)
    ft.dropdown = types.SimpleNamespace(Option=Ctl)
    return ft


def walk(c, seen=None):
    seen = seen if seen is not None else set()
    if id(c) in seen or not isinstance(c, Ctl):
        return
    seen.add(id(c))
    yield c
    for ch in list(c.controls) + list(c.args):
        if isinstance(ch, list):
            for x in ch:
                yield from walk(x, seen)
        else:
            yield from walk(ch, seen)
    for attr in ("content", "title", "actions", "options"):
        v = getattr(c, attr, None)
        if isinstance(v, list):
            for x in v:
                yield from walk(x, seen)
        elif isinstance(v, Ctl):
            yield from walk(v, seen)


class Page:
    def __init__(self):
        self.controls, self.overlay, self.opened = [], [], []
        self.navigation_bar = None
        self.clipboard = ""

    def add(self, *c): self.controls.extend(c)
    def clean(self): self.controls.clear()
    def update(self): pass
    def open(self, c): self.opened.append(c)
    def close(self, c): pass
    def run_thread(self, fn, *a): fn(*a)
    def set_clipboard(self, t): self.clipboard = t


def texts(root):
    return [c.args[0] for c in walk(root) if c.__class__ is Ctl and c.args and isinstance(c.args[0], str)]


def click(root, label):
    """Click the first control with an on_click whose subtree shows `label`."""
    for c in walk(root):
        if getattr(c, "on_click", None) and (c.args[:1] == (label,) or label in texts(c)):
            c.on_click(None)
            return True
    raise AssertionError(f"no clickable '{label}'")


BINLIST_OK = {"scheme": "visa", "type": "debit", "brand": "Visa Infinite", "prepaid": False,
              "number": {"luhn": True}, "country": {"name": "Italy", "alpha2": "IT", "alpha3": "ITA", "currency": "EUR"},
              "bank": {"name": "Revolut Bank UAB"}}


class Smoke(unittest.TestCase):
    def test_full_flow(self):
        ft = make_ft()
        with mock.patch.dict(sys.modules, {"flet": ft}):
            sys.modules.pop("main", None)
            import main as app
            resp = mock.Mock(status_code=200); resp.json.return_value = BINLIST_OK
            with mock.patch("engine.requests.get", return_value=resp), mock.patch("time.sleep"):
                page = Page()
                app.main(page)
                self.assertIsNotNone(page.navigation_bar, "app failed to start: " + " ".join(texts(page)))
                root = page.controls[0]
                bar = page.navigation_bar

                # --- Lookup: type a BIN + note, look up, save with note
                fields = {c.label: c for c in walk(root) if c.__class__ is Ctl and hasattr(c, "label")}
                bin_in = next(v for k, v in fields.items() if k.startswith("BIN"))
                note_in = next(v for k, v in fields.items() if k.startswith("Note to save"))
                bin_in.value, note_in.value = "416598, 531416", "client A"
                click(root, "Look up")
                shown = " ".join(texts(root))
                self.assertIn("REVOLUT BANK UAB", shown); self.assertIn("Copy all reports", shown)
                for card_note in [c for c in walk(root) if getattr(c, "label", "").startswith("Note - saved")]:
                    self.assertEqual(card_note.value, "client A")        # top note seeds each card
                click(root, "Save")
                self.assertIn("Saved to the Saved tab", " ".join(texts(page.opened[-1])))
                from engine import BinEngine
                self.assertEqual([(r["bin"], r["note"]) for r in BinEngine().saved()], [("416598", "client A")])
                self.assertIn("Update note", " ".join(texts(root)))        # card flipped to the saved state

                # --- Banks: cascading dropdowns
                bar.on_change(types.SimpleNamespace(control=types.SimpleNamespace(selected_index=1)))
                dds = [c for c in walk(root) if c.__class__ is Ctl and getattr(c, "label", "") in ("Country", "Brand", "Bank", "Type", "Level")]
                self.assertEqual([d.label for d in dds], ["Country", "Brand", "Bank", "Type", "Level"])
                country = dds[0]
                self.assertTrue(any(o.key == "IT" for o in country.options))
                country.value = "IT"; country.on_change(None)
                self.assertEqual([o.key for o in dds[1].options], ["__all__", "VISA"])
                click(root, "Search")
                self.assertIn("416598  ·  REVOLUT BANK UAB", " ".join(texts(root)))
                click(root, "Reset")
                self.assertEqual(country.value, "__all__")

                # --- Learn: Luhn multi-check
                bar.on_change(types.SimpleNamespace(control=types.SimpleNamespace(selected_index=2)))
                t = " ".join(texts(root))
                self.assertIn("3 pass · 3 fail", t)

                # --- Saved: note visible, tap opens details in place (no Lookup tab)
                bar.on_change(types.SimpleNamespace(control=types.SimpleNamespace(selected_index=3)))
                self.assertIn("\u270E client A", " ".join(texts(root)))
                tile = next(c for c in walk(root) if getattr(c, "on_click", None) and any("416598" in x for x in texts(c)))
                tile.on_click(None)
                detail = " ".join(texts(app_body := page.controls[0]))
                self.assertIn("BIN details", detail); self.assertIn("REVOLUT BANK UAB", detail)

    def test_settings_dialog(self):
        ft = make_ft()
        with mock.patch.dict(sys.modules, {"flet": ft}):
            sys.modules.pop("main", None)
            import main as app
            with mock.patch("time.sleep"):
                page = Page(); app.main(page); root = page.controls[0]
                gear = next(c for c in walk(root) if getattr(c, "tooltip", "") == "API keys & sources")
                gear.on_click(None)
                dlg = page.opened[-1]
                fields = {c.label: c for c in walk(dlg) if getattr(c, "label", None)}
                handy = next(v for k, v in fields.items() if k.startswith("HandyAPI"))
                handy.value = "HAS-" + "q" * 20
                next(a for a in dlg.actions if a.args[0] == "Save & test").on_click(None)
                self.assertTrue(any("SECRET" in s for s in texts(dlg)))
                handy.value = "PUB-" + "q" * 20
                resp = mock.Mock(status_code=401)
                with mock.patch("engine.requests.get", return_value=resp):
                    next(a for a in dlg.actions if a.args[0] == "Save & test").on_click(None)
                self.assertTrue(any("key rejected" in s for s in texts(dlg)))


if __name__ == "__main__":
    unittest.main()
