"""BIN Atlas v1.1 - BIN lookup, issuer search and Luhn practice (Flet, Android-ready).

Tabs: Lookup | Banks | Learn (Luhn checker) | Saved      Gear icon: API keys & sources
"""
import time
import traceback

import flet as ft

from engine import (BinEngine, extract_bins, flag_emoji, had_extra_digits,
                    luhn_batch, luhn_steps)
from logo_data import LOGO_B64

ICONS = getattr(ft, "Icons", None) or ft.icons   # Flet renamed ft.icons -> ft.Icons

BG, CARD_BG, BOX_BG = "#04141C", "#081E29", "#0B2532"
CYAN, BORDER, WHITE, MUTED = "#00F0FF", "#134E5E", "#FFFFFF", "#7A9CAE"
GOLD, ORANGE, GREEN, RED = "#FFD700", "#FF9800", "#00E676", "#FF5252"
ALL = "__all__"

STATUS_LABEL = {
    "live": ("Live data", GREEN),
    "cached": ("Cached data", CYAN),
    "stale": ("Cached (may be outdated)", ORANGE),
    "sample": ("Bundled sample - unverified", ORANGE),
}
TYPE_COLOR = {"CREDIT": GOLD, "DEBIT": GREEN, "PREPAID": ORANGE}
DISCLAIMER = ("Public BIN data can be incomplete or outdated. Information only - "
              "not for identity, credit or compliance decisions.")
PRACTICE = "79927398713\n79927398710\n49927398716\n49927398717\n1234567812345670\n1234567812345671"


# ------------------------------------------------------------------ widgets
def logo(size):
    return ft.Image(src_base64=LOGO_B64, width=size, height=size, fit=ft.ImageFit.CONTAIN)


def card(*controls, title=None, border=BORDER):
    kids = []
    if title:
        kids.append(ft.Text(title, size=14, color=CYAN, weight=ft.FontWeight.W_600))
    kids.extend(controls)
    return ft.Container(bgcolor=CARD_BG, border=ft.border.all(1, border), border_radius=14,
                        padding=16, content=ft.Column(kids, spacing=10))


def capsule(label, value, color=WHITE):
    return ft.Container(
        expand=True, bgcolor=BOX_BG, border=ft.border.all(1, BORDER), border_radius=10,
        padding=ft.padding.symmetric(vertical=8, horizontal=10),
        content=ft.Column([
            ft.Text(label, size=10, color=MUTED),
            ft.Text(str(value), size=13, color=color, weight=ft.FontWeight.W_500, selectable=True),
        ], spacing=2))


def row2(a, b):
    return ft.Row([a, b], spacing=8)


def button(text, on_click, primary=False, icon=None, expand=1, color=None):
    fg = BG if primary else (color or CYAN)
    kids = ([ft.Icon(icon, color=fg, size=18)] if icon else []) + \
           [ft.Text(text, color=fg, weight=ft.FontWeight.BOLD, size=14)]
    return ft.Container(
        content=ft.Row(kids, alignment=ft.MainAxisAlignment.CENTER, spacing=6),
        bgcolor=CYAN if primary else BOX_BG,
        border=ft.border.all(1, CYAN if primary else (color or BORDER)), border_radius=12,
        padding=ft.padding.symmetric(vertical=12), expand=expand, on_click=on_click, ink=True)


def field(label, quiet=False, **kw):
    f = ft.TextField(label=label, border_color=BORDER, focused_border_color=CYAN,
                     border_radius=10, bgcolor=BOX_BG, color=WHITE,
                     label_style=ft.TextStyle(color=MUTED, size=12), **kw)
    if quiet:
        # Keyboard suggestions/auto-correct fight with Android's text composing and
        # were part of the "can't delete the last digit" bug. Set defensively: unknown
        # attributes are ignored on Flet versions that lack them.
        for attr in ("autocorrect", "enable_suggestions"):
            try:
                setattr(f, attr, False)
            except Exception:
                pass
    return f


def dropdown(label, on_change):
    return ft.Dropdown(
        label=label, value=ALL, options=[ft.dropdown.Option(key=ALL, text="All")], expand=True,
        border_color=BORDER, focused_border_color=CYAN, border_radius=10, bgcolor=BOX_BG,
        color=WHITE, text_size=13, label_style=ft.TextStyle(color=MUTED, size=12),
        on_change=on_change)


def chip(label, on_tap):
    return ft.Container(
        content=ft.Text(label, size=12, color=WHITE), bgcolor=BOX_BG,
        border=ft.border.all(1, BORDER), border_radius=18,
        padding=ft.padding.symmetric(vertical=7, horizontal=14), on_click=on_tap, ink=True)


def pill(text, color):
    return ft.Container(
        content=ft.Text(text, size=11, color=color, weight=ft.FontWeight.BOLD),
        border=ft.border.all(1, color), border_radius=14,
        padding=ft.padding.symmetric(vertical=3, horizontal=10))


def splash():
    return ft.Container(
        expand=True, bgcolor=BG, alignment=ft.alignment.center,
        content=ft.Column([
            logo(132),
            ft.Text("BIN Atlas", size=30, weight=ft.FontWeight.BOLD, color=WHITE),
            ft.Text("Issuer intelligence at a glance", size=13, color=CYAN),
            ft.Container(height=22),
            ft.ProgressBar(width=190, color=CYAN, bgcolor=BOX_BG),
        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            alignment=ft.MainAxisAlignment.CENTER, spacing=8))


# ---------------------------------------------------------------------- app
def build_app(page: ft.Page, engine: BinEngine):
    body = ft.Container(expand=True, padding=12)

    def snack(msg, color=CYAN):
        page.open(ft.SnackBar(ft.Text(msg, color=BG, weight=ft.FontWeight.BOLD), bgcolor=color))

    def copy(text, msg="Copied!"):
        page.set_clipboard(text)
        snack(msg, GREEN)

    def app_header(title, subtitle):
        return ft.Container(
            bgcolor=CARD_BG, border=ft.border.all(1, CYAN), border_radius=14,
            padding=ft.padding.only(left=12, top=10, bottom=10, right=4),
            content=ft.Row([
                logo(42),
                ft.Column([ft.Text(title, size=19, weight=ft.FontWeight.BOLD, color=WHITE),
                           ft.Text(subtitle, size=11, color=CYAN)], spacing=1, expand=True),
                ft.IconButton(ICONS.SETTINGS, icon_color=CYAN, tooltip="API keys & sources",
                              on_click=lambda _: open_settings()),
            ], spacing=10))

    def flag_of(r):
        return flag_emoji(r.get("country_code", ""))

    # ------------------------------------------------------- result card
    def result_card(d, holder, seed_note=""):
        """One BIN card (HandyAPI-style fields). `holder` is the Container that shows
        it, so Save/Remove/Refresh can swap in an updated card in place."""
        if not d["found"]:
            guess = ("" if d["detected_scheme"] == "UNKNOWN" else
                     f"Network guessed from prefix: {d['detected_scheme']}"
                     f"{' · length ' + d['expected_length'] if d['expected_length'] else ''}")
            return card(
                ft.Text(f"BIN {d['bin']}", size=20, weight=ft.FontWeight.BOLD, color=WHITE),
                ft.Text(d["message"], color=ORANGE, size=13),
                ft.Text(guess, color=MUTED, size=12, visible=bool(guess)),
                ft.Text(d.get("trail", ""), color=MUTED, size=10, visible=bool(d.get("trail"))),
                title="No issuer data", border=ORANGE)

        saved = bool(d.get("favorite"))
        label, color = STATUS_LABEL.get(d["status"], ("", MUTED))
        note_field = field("Note - saved together with this BIN",
                           value=(d.get("note") if saved else seed_note) or "",
                           text_size=13, max_length=120)

        def rebuild(msg=None, mcolor=GREEN, fresh=None):
            holder.content = result_card(fresh or engine.get_record(d["bin"]), holder, seed_note)
            if msg:
                snack(msg, mcolor)
            else:
                page.update()

        def do_save(_):
            if engine.save_bin(d["bin"], note_field.value or ""):
                rebuild("Saved to the Saved tab." if not saved else "Note updated.")

        def do_remove(_):
            engine.unsave_bin(d["bin"])
            rebuild("Removed from Saved.", ORANGE)

        def do_refresh(_):
            def work():
                fresh = engine.lookup(d["bin"], allow_network=True, force_refresh=True)
                rebuild(fresh["message"] or "Refreshed.",
                        GREEN if fresh["status"] == "live" else ORANGE, fresh)
            page.run_thread(work)

        t = d["type"]
        save_row = (
            ft.Row([button("Update note", do_save, primary=True, icon=ICONS.BOOKMARK),
                    button("Remove", do_remove, icon=ICONS.DELETE_OUTLINE, color=RED)], spacing=8)
            if saved else
            ft.Row([button("Save", do_save, primary=True, icon=ICONS.BOOKMARK_ADD)], spacing=8))
        return card(
            ft.Row([
                ft.Text(d["flag"], size=44),
                ft.Column([ft.Text(d["bin"], size=24, weight=ft.FontWeight.BOLD, color=WHITE),
                           ft.Text(f"{d['scheme']} · {t} · {d['brand']}", size=12, color=MUTED)],
                          spacing=2, expand=True),
                ft.Icon(ICONS.BOOKMARK if saved else ICONS.BOOKMARK_BORDER,
                        color=GOLD if saved else MUTED, size=26),
            ], spacing=10),
            ft.Row([pill(t if t != "N/A" else "TYPE N/A", TYPE_COLOR.get(t, MUTED)),
                    pill(label, color)], spacing=8, wrap=True),
            ft.Text(d["message"], size=11, color=ORANGE, visible=bool(d["message"])),
            row2(capsule("Scheme", d["scheme"]), capsule("Type", t, TYPE_COLOR.get(t, WHITE))),
            row2(capsule("Tier / level", d["brand"]), capsule("Luhn", d["luhn"])),
            ft.Row([capsule("Issuer / bank", d["bank"])]),
            row2(capsule("Country", f"{d['country']} ({d['country_code'] or 'N/A'}/{d['country_a3']})"),
                 capsule("Continent", d["continent"])),
            row2(capsule("Dial code", d["dial_code"]), capsule("Currency", d["currency"])),
            row2(capsule("Prepaid", d["prepaid"]), capsule("Commercial", d["commercial"])),
            row2(capsule("Issuer phone", d["phone"]), capsule("Website", d["url"])),
            row2(capsule("Network by prefix", d["detected_scheme"]),
                 capsule("Typical length", d["expected_length"] or "N/A")),
            ft.Text(f"Source: {d['source']}" + (f" · fetched {d['fetched_at'][:10]}" if d.get("fetched_at") else ""),
                    size=11, color=MUTED),
            ft.Text(d.get("trail", ""), size=10, color=MUTED, visible=bool(d.get("trail"))),
            note_field, save_row,
            ft.Row([button("Copy", lambda _: copy(engine.format_report(d, note_field.value)),
                           icon=ICONS.CONTENT_COPY),
                    button("Refresh", do_refresh, icon=ICONS.REFRESH)], spacing=8),
            border=CYAN)

    def holder_for(d, seed_note=""):
        h = ft.Container()
        h.content = result_card(d, h, seed_note)
        return h

    def tile(r, back_idx):
        note = (r.get("note") or "").strip()
        return ft.Container(
            bgcolor=BOX_BG, border=ft.border.all(1, BORDER), border_radius=10, padding=10, ink=True,
            on_click=lambda _, b=r["bin"]: show_detail(b, back_idx),
            content=ft.Row([
                ft.Text(flag_of(r), size=24),
                ft.Column([
                    ft.Text(f"{r['bin']}  ·  {str(r.get('bank'))[:30]}", size=13, color=WHITE,
                            weight=ft.FontWeight.W_600),
                    ft.Text(f"{r['scheme']} · {r['type']} · {r['brand']}", size=11, color=MUTED),
                    ft.Text(f"\u270E {note}", size=11, color=GOLD, visible=bool(note)),
                ], spacing=2, expand=True),
                ft.Icon(ICONS.BOOKMARK if r.get("favorite") else ICONS.CHEVRON_RIGHT,
                        color=GOLD if r.get("favorite") else MUTED, size=18),
            ], spacing=10))

    def show_detail(b, back_idx):
        """Show a stored BIN's full card in place (no jump to the Lookup tab)."""
        holder = holder_for(engine.get_record(b))
        body.content = ft.Column([
            ft.Row([ft.IconButton(ICONS.ARROW_BACK, icon_color=CYAN, on_click=lambda _: show(back_idx)),
                    ft.Text("BIN details", size=16, color=WHITE, weight=ft.FontWeight.W_600)]),
            holder,
        ], spacing=8, scroll=ft.ScrollMode.AUTO, expand=True)
        page.update()

    # ------------------------------------------------------- settings
    def open_settings():
        k_handy = field("HandyAPI key (publishable, starts with PUB-)", value=engine.get_setting("handyapi_key"),
                        password=True, can_reveal_password=True, text_size=13)
        k_bl = field("binlist.io key (starts with bl_)", value=engine.get_setting("binlistio_key"),
                     password=True, can_reveal_password=True, text_size=13)
        combine = ft.Switch(label="Combine sources for fuller data", value=engine.get_setting("combine", "1") == "1",
                            active_color=CYAN, label_style=ft.TextStyle(size=12, color=MUTED))
        status = ft.Column(spacing=2)

        def save(_=None):
            problems = engine.set_api_keys(k_handy.value or "", k_bl.value or "")
            if problems:
                status.controls = [ft.Text(p, size=12, color=RED) for p in problems]
                page.update()
                return False
            engine.set_setting("combine", "1" if combine.value else "0")
            refresh_banner()
            return True

        def save_and_test(_):
            if not save():
                return
            status.controls = [ft.Text("Testing sources...", size=12, color=MUTED)]
            page.update()

            def work():
                res = engine.test_providers()
                status.controls = [
                    ft.Text(f"{'✓' if ok else '✗'}  {name}: {msg}", size=12, color=GREEN if ok else ORANGE)
                    for name, (ok, msg) in res.items()]
                page.update()
            page.run_thread(work)

        dlg = ft.AlertDialog(
            modal=True, bgcolor=CARD_BG,
            title=ft.Text("API keys & sources", color=WHITE, size=18),
            content=ft.Container(width=330, content=ft.Column([
                ft.Text("Lookups try binlist.io, then HandyAPI, then binlist.net, and switch "
                        "automatically if one fails. Keys stay on this device only.",
                        size=12, color=MUTED),
                k_bl, k_handy, combine, status,
                ft.Text("Use only the publishable PUB- key here. Never put a secret (HAS-) key in a mobile app.",
                        size=11, color=ORANGE),
            ], spacing=10, tight=True, scroll=ft.ScrollMode.AUTO)),
            actions=[ft.TextButton("Close", on_click=lambda _: page.close(dlg)),
                     ft.TextButton("Save", on_click=lambda _: (save() and snack("Saved.", GREEN))),
                     ft.TextButton("Save & test", on_click=save_and_test)],
            actions_alignment=ft.MainAxisAlignment.END)
        page.open(dlg)

    # ========================================================== LOOKUP
    bin_input = field("BIN - first 6 digits (separate several with commas)", value="",
                      quiet=True, max_length=300)
    note_input = field("Note to save with the BIN (optional)", text_size=13, max_length=120)
    offline_switch = ft.Switch(label="Offline mode (local data only)", value=False, active_color=CYAN,
                               label_style=ft.TextStyle(size=12, color=MUTED))
    progress = ft.ProgressBar(color=CYAN, bgcolor=BOX_BG, visible=False)
    results_col = ft.Column(spacing=12)
    recent_row = ft.Row(spacing=8, wrap=True, run_spacing=8)
    key_banner = ft.Container(
        bgcolor="#2A1E05", border=ft.border.all(1, ORANGE), border_radius=12, padding=12, ink=True,
        on_click=lambda _: open_settings(),
        content=ft.Row([ft.Icon(ICONS.KEY, color=ORANGE, size=20),
                        ft.Text("Add your free API keys (tap here) so lookups keep working when a source is busy.",
                                size=12, color=WHITE, expand=True)], spacing=10))

    def refresh_banner():
        key_banner.visible = not engine.has_keys()

    def refresh_recent():
        recent_row.controls = [chip(h["bin"], lambda _, b=h["bin"]: quick(b)) for h in engine.history(5)]

    def quick(b):
        bin_input.value = b
        run_lookup()

    def run_lookup(_=None):
        raw = bin_input.value or ""
        bins = extract_bins(raw)
        if not bins:
            snack("Enter at least 6 digits of a BIN.", ORANGE)
            return
        if had_extra_digits(raw):
            snack("Only the first 6 digits are used; the rest is ignored and never stored.", ORANGE)
        progress.visible = True
        results_col.controls.clear()
        page.update()
        offline, seed = offline_switch.value, (note_input.value or "").strip()

        def work():
            try:
                out = [engine.lookup(b, allow_network=not offline) for b in bins]
                results_col.controls = [holder_for(d, seed) for d in out]
                found = [d for d in out if d["found"]]
                if len(found) > 1:
                    text = "\n\n".join(engine.format_report(d, seed) for d in found)
                    results_col.controls.append(
                        button("Copy all reports", lambda _: copy(text), icon=ICONS.CONTENT_COPY))
                refresh_recent()
            except Exception as exc:     # never leave the UI stuck on "loading"
                snack(f"Lookup failed: {exc}", RED)
            finally:
                progress.visible = False
                page.update()
        page.run_thread(work)

    refresh_recent()
    refresh_banner()
    lookup_view = ft.Column([
        app_header("BIN Atlas", "Issuer, network, country and card type from a BIN"),
        key_banner,
        card(bin_input, note_input, offline_switch,
             ft.Text("Official test BINs", size=12, color=MUTED),
             ft.Row([chip("Visa 424242", lambda _: quick("424242")),
                     chip("MC 510510", lambda _: quick("510510")),
                     chip("Amex 378282", lambda _: quick("378282"))], spacing=8, wrap=True),
             ft.Text("Recent", size=12, color=MUTED), recent_row,
             ft.Row([button("Clear", lambda _: (setattr(bin_input, "value", ""), page.update())),
                     button("Look up", run_lookup, primary=True, icon=ICONS.SEARCH, expand=2)], spacing=10),
             title="Input"),
        progress, results_col,
        ft.Text(DISCLAIMER, size=10, color=MUTED, text_align=ft.TextAlign.CENTER),
    ], spacing=12, scroll=ft.ScrollMode.AUTO, expand=True)

    # =========================================================== BANKS
    dd_country = dropdown("Country", lambda e: refresh_facets(dd_country))
    dd_scheme = dropdown("Brand", lambda e: refresh_facets(dd_scheme))
    dd_bank = dropdown("Bank", lambda e: refresh_facets(dd_bank))
    dd_type = dropdown("Type", lambda e: refresh_facets(dd_type))
    dd_level = dropdown("Level", lambda e: None)
    chain = [dd_country, dd_scheme, dd_bank, dd_type, dd_level]
    s_results = ft.Column(spacing=6)
    s_progress = ft.ProgressBar(color=CYAN, bgcolor=BOX_BG, visible=False)
    last_rows = {"rows": []}
    picker = {}

    def sel(d):
        return "" if d.value in (None, ALL) else d.value

    def set_opts(d, items):
        keys = {k for k, _ in items}
        d.options = [ft.dropdown.Option(key=ALL, text="All")] + \
                    [ft.dropdown.Option(key=k, text=t) for k, t in items[:1500]]
        if d.value not in keys:
            d.value = ALL

    def refresh_facets(changed=None):
        """Left-to-right cascade: choosing a country narrows brands, banks, types, levels."""
        if changed in chain:
            for d in chain[chain.index(changed) + 1:]:
                d.value = ALL
        f = engine.facets(sel(dd_country), sel(dd_scheme), sel(dd_bank), sel(dd_type))
        set_opts(dd_country, [(cc, f"{flag_emoji(cc)} {name.title()} ({cc})") for cc, name in f["countries"]])
        set_opts(dd_scheme, [(v, v) for v in f["schemes"]])
        set_opts(dd_bank, [(v, v) for v in f["banks"]])
        set_opts(dd_type, [(v, v) for v in f["types"]])
        set_opts(dd_level, [(v, v) for v in f["levels"]])
        page.update()

    def do_search(_=None):
        rows = engine.search_filters(sel(dd_country), sel(dd_scheme), sel(dd_bank), sel(dd_type), sel(dd_level))
        last_rows["rows"] = rows
        s_results.controls = (
            [ft.Text(f"{len(rows)} BIN(s) found" + (" (showing first 300)" if len(rows) >= 300 else ""),
                     size=12, color=MUTED)] + [tile(r, 1) for r in rows]
            if rows else
            [ft.Text("No BINs match. Look up more BINs, or import a BIN list below.", color=ORANGE, size=12)])
        page.update()

    def do_reset(_=None):
        for d in chain:
            d.value = ALL
        last_rows["rows"] = []
        s_results.controls = []
        refresh_facets()

    def export_results(_):
        rows = last_rows["rows"] or engine.search_filters()
        path, text = engine.export_csv_file(rows)
        copy(text, f"CSV copied ({len(rows)} rows). Also saved: {path}")

    def on_file_picked(e):
        if not e.files:
            return
        path = e.files[0].path
        if not path:
            snack("Could not read that file's path on this device.", RED)
            return
        s_progress.visible = True
        page.update()

        def work():
            try:
                r = engine.import_csv(path)
                snack(f"Imported {r['added']} new BINs ({r['rows']} rows read).", GREEN)
                refresh_facets()
            except Exception as exc:
                snack(f"Import failed: {exc}", RED)
            finally:
                s_progress.visible = False
                page.update()
        page.run_thread(work)

    def import_csv(_):
        if "p" not in picker:
            picker["p"] = ft.FilePicker(on_result=on_file_picked)
            page.overlay.append(picker["p"])
            page.update()
        picker["p"].pick_files(dialog_title="Choose a BIN list (CSV)", allow_multiple=False,
                               file_type=ft.FilePickerFileType.CUSTOM, allowed_extensions=["csv"])

    search_view = ft.Column([
        app_header("Banks & Issuers", "Filter the BINs stored on this device"),
        card(row2(dd_country, dd_scheme), ft.Row([dd_bank]), row2(dd_type, dd_level),
             ft.Row([button("Search", do_search, primary=True, icon=ICONS.SEARCH),
                     button("Reset", do_reset, icon=ICONS.RESTART_ALT, color=RED)], spacing=10),
             ft.Row([button("Export CSV", export_results, icon=ICONS.DOWNLOAD)])),
        s_results,
        card(ft.Text("The filters list the BINs on this device and grow with every lookup. To fill them "
                     "faster, import a public BIN list as CSV (columns like BIN, Brand, Type, Category, "
                     "Issuer, isoCode2, CountryName).", size=12, color=MUTED),
             s_progress, button("Import BIN list (CSV)", import_csv, icon=ICONS.UPLOAD_FILE),
             title="Grow your offline database"),
    ], spacing=12, scroll=ft.ScrollMode.AUTO, expand=True)

    # ============================================== LEARN (Luhn checker)
    luhn_input = field("Numbers to check - one per line or separated by commas (max 25)",
                       value=PRACTICE, quiet=True, multiline=True, min_lines=4, max_lines=8, text_size=13)
    luhn_out = ft.Column(spacing=8)

    def steps_view(item):
        res = luhn_steps(item["digits"])
        boxes = [ft.Container(
            width=36, padding=3, border_radius=8,
            bgcolor="#103342" if s["doubled"] else BOX_BG,
            border=ft.border.all(1, CYAN if s["doubled"] else BORDER),
            content=ft.Column([
                ft.Text(str(s["digit"]), size=15, weight=ft.FontWeight.BOLD, color=WHITE),
                ft.Text(f"x2→{s['value']}" if s["doubled"] else str(s["value"]), size=9,
                        color=CYAN if s["doubled"] else MUTED)],
                spacing=0, horizontal_alignment=ft.CrossAxisAlignment.CENTER)) for s in res["steps"]]
        ok = res["valid"]
        return ft.Column([
            ft.Row(boxes, wrap=True, spacing=3, run_spacing=3),
            ft.Text("Highlighted digits are doubled (every 2nd digit from the right); a doubled value above 9 "
                    "has 9 subtracted.", size=10, color=MUTED),
            ft.Text(f"Sum = {res['total']}  →  {'divisible by 10: PASSES' if ok else 'not divisible by 10: FAILS'}",
                    size=12, weight=ft.FontWeight.BOLD, color=GREEN if ok else RED)], spacing=6)

    def luhn_row(item):
        detail = ft.Container(visible=False, padding=ft.padding.only(top=6))
        if item["valid"] is None:
            verdict, vcolor = item["error"] or "n/a", ORANGE
        else:
            verdict, vcolor = ("PASS", GREEN) if item["valid"] else ("FAIL", RED)
        extra = f"{item['length']} digits"
        if item["scheme"] != "UNKNOWN":
            extra += f" · {item['scheme']}" + ("" if item["length_ok"] is not False else " · unusual length")

        def toggle(_):
            if item["valid"] is None:
                return
            if not detail.content:
                detail.content = steps_view(item)
            detail.visible = not detail.visible
            page.update()
        return ft.Container(
            bgcolor=BOX_BG, border=ft.border.all(1, BORDER), border_radius=10, padding=10, ink=True,
            on_click=toggle,
            content=ft.Column([
                ft.Row([ft.Text(f"{item['index']}.", size=12, color=MUTED),
                        ft.Column([ft.Text(item["masked"], size=14, color=WHITE, weight=ft.FontWeight.W_600,
                                           selectable=True), ft.Text(extra, size=11, color=MUTED)],
                                  spacing=1, expand=True),
                        pill(verdict, vcolor)], spacing=10),
                detail], spacing=0))

    def run_luhn(_=None):
        res = luhn_batch(luhn_input.value or "")
        if not res["items"]:
            luhn_out.controls = [ft.Text("Enter at least one number.", color=ORANGE, size=12)]
        else:
            luhn_out.controls = (
                [ft.Text(f"{res['passed']} pass · {res['failed']} fail" +
                         (" · only the first 25 were checked" if res["truncated"] else "") +
                         "  (tap a row for the step-by-step)", size=12, color=CYAN)]
                + [luhn_row(i) for i in res["items"]])
        page.update()

    luhn_view = ft.Column([
        app_header("Learn · Luhn checker", "Practice the checksum behind card numbers"),
        card(luhn_input,
             ft.Row([button("Practice set", lambda _: (setattr(luhn_input, "value", PRACTICE), run_luhn())),
                     button("Clear", lambda _: (setattr(luhn_input, "value", ""),
                                                setattr(luhn_out, "controls", []), page.update()))], spacing=8),
             button("Check all", run_luhn, primary=True, icon=ICONS.FACT_CHECK),
             ft.Text("Runs on your device only. Nothing is sent or stored. Long numbers are shown masked.",
                     size=10, color=MUTED), title="Luhn checker (multiple numbers)"),
        luhn_out,
        card(ft.Text("• First digit: Major Industry Identifier (4 Visa, 5/2 Mastercard, 3 Amex/JCB...)\n"
                     "• First 6-8 digits: the BIN / IIN - identifies the issuing bank and product\n"
                     "• Middle digits: the account identifier\n"
                     "• Last digit: a Luhn check digit that catches typing mistakes",
                     size=12, color=WHITE),
             ft.Text("Passing Luhn only means the digits are consistent. It does not mean a card exists "
                     "or is active.", size=11, color=MUTED), title="Anatomy of a card number"),
    ], spacing=12, scroll=ft.ScrollMode.AUTO, expand=True)

    # ============================================================ SAVED
    saved_q = field("Search saved BINs by number, bank, country or note", text_size=13)
    saved_list, hist_list = ft.Column(spacing=6), ft.Column(spacing=6)
    saved_title, hist_title = ft.Text("", size=14, color=CYAN, weight=ft.FontWeight.W_600), \
        ft.Text("", size=14, color=CYAN, weight=ft.FontWeight.W_600)

    def refresh_saved(_=None):
        favs = engine.saved(saved_q.value or "")
        hist = engine.history(40)
        saved_title.value = f"Saved ({len(favs)})"
        saved_list.controls = [tile(r, 3) for r in favs] or [
            ft.Text("Nothing here yet. Look up a BIN, add a note and tap Save." if not saved_q.value
                    else "No saved BIN matches that search.", size=12, color=MUTED)]
        hist_title.value = f"History ({len(hist)})"
        hist_list.controls = [tile(r, 3) for r in hist] or [ft.Text("No lookups yet.", size=12, color=MUTED)]
        page.update()

    def export_saved(_):
        rows = engine.saved() + [h for h in engine.history(200) if not h["favorite"]]
        path, text = engine.export_csv_file(rows)
        copy(text, f"CSV copied. Also saved: {path}")

    def clear_history(_):
        engine.clear_history()
        refresh_saved()
        snack("History cleared (saved BINs kept).", GREEN)

    saved_q.on_change = refresh_saved
    saved_view = ft.Column([
        app_header("Saved", "Your saved BINs with notes, and history"),
        card(saved_q), saved_title, saved_list, hist_title, hist_list,
        ft.Row([button("Export CSV", export_saved, icon=ICONS.DOWNLOAD),
                button("Clear history", clear_history, icon=ICONS.DELETE_OUTLINE)], spacing=10),
    ], spacing=12, scroll=ft.ScrollMode.AUTO, expand=True)

    # ======================================================== NAVIGATION
    def show(idx):
        page.navigation_bar.selected_index = idx
        if idx == 0:
            body.content = lookup_view
        elif idx == 1:
            body.content = search_view
            refresh_facets()
        elif idx == 2:
            body.content = luhn_view
            if not luhn_out.controls:
                run_luhn()
        else:
            body.content = saved_view
            refresh_saved()
        page.update()

    page.navigation_bar = ft.NavigationBar(
        bgcolor=CARD_BG, indicator_color=BORDER, selected_index=0,
        on_change=lambda e: show(e.control.selected_index),
        destinations=[
            ft.NavigationBarDestination(icon=ICONS.SEARCH, label="Lookup"),
            ft.NavigationBarDestination(icon=ICONS.ACCOUNT_BALANCE, label="Banks"),
            ft.NavigationBarDestination(icon=ICONS.SCHOOL, label="Learn"),
            ft.NavigationBarDestination(icon=ICONS.BOOKMARK, label="Saved"),
        ])
    page.add(ft.SafeArea(body, expand=True))
    body.content = lookup_view
    page.update()


def main(page: ft.Page):
    page.title = "BIN Atlas"
    page.bgcolor = BG
    page.padding = 0
    page.theme_mode = ft.ThemeMode.DARK
    page.add(splash())                    # branded loading screen instead of a blank/white one
    page.update()
    try:
        engine = BinEngine()              # opens/migrates the database while the splash is visible
        time.sleep(0.8)
        page.clean()
        build_app(page, engine)
    except Exception:                     # show the error on screen instead of freezing on the splash
        page.clean()
        page.add(ft.SafeArea(ft.Column([
            ft.Text("BIN Atlas could not start", size=18, color=RED, weight=ft.FontWeight.BOLD),
            ft.Text(traceback.format_exc(), size=11, color=WHITE, selectable=True)],
            scroll=ft.ScrollMode.AUTO), expand=True))
        page.update()


if __name__ == "__main__":
    ft.app(target=main)
