"""BIN Atlas - data engine v2 (no UI dependencies, unit-testable).

Providers (tried in this order, with automatic failover):
    1. binlist.io   (free key: 10,000 requests/day)
    2. HandyAPI     (free key, "x-api-key" header; publishable PUB- key only)
    3. binlist.net  (no key, strict hourly limit)

API keys are NEVER stored in source code. The user enters them in the app's
Settings screen; they are kept in the app's private storage on the device.

Privacy: only the first 6 digits (the BIN/IIN) are ever sent or stored.
"""
from __future__ import annotations

import csv
import io
import os
import re
import sqlite3
import time
from contextlib import closing
from datetime import datetime, timedelta

import requests

CACHE_TTL_DAYS = 90
NEG_CACHE_HOURS = 24
HTTP_TIMEOUT = 7
USER_AGENT = "BINAtlas/1.1 (educational app)"
SAMPLE_SOURCE = "Sample data"
TS_FMT = "%Y-%m-%d %H:%M:%S"
NA_VALUES = (None, "", "N/A", "UNKNOWN")
COMMERCIAL_WORDS = ("BUSINESS", "CORPORATE", "COMMERCIAL")

# Column semantics (kept from v1 for backwards compatibility):
#   scheme = card network ("Brand" on bincheck.io), brand = product level/tier
FIELDS = ["scheme", "type", "brand", "bank", "phone", "url", "country",
          "country_code", "country_a3", "continent", "dial_code", "currency",
          "prepaid", "commercial", "luhn"]
FILTER_COLUMNS = ("country_code", "scheme", "bank", "type", "brand")

SCHEMA_COLUMNS = (
    [("bin", "TEXT PRIMARY KEY")]
    + [(f, "TEXT DEFAULT 'N/A'") for f in FIELDS]
    + [("source", "TEXT"), ("fetched_at", "TEXT"), ("looked_up_at", "TEXT"),
       ("lookup_count", "INTEGER DEFAULT 0"), ("favorite", "INTEGER DEFAULT 0"),
       ("note", "TEXT DEFAULT ''"), ("saved_at", "TEXT")]
)

PROVIDER_NAMES = ("binlist.io", "handyapi", "binlist.net")
COOLDOWN_SECONDS = {
    "ratelimited": {"binlist.io": 60, "handyapi": 30, "binlist.net": 900},
    "error": 45,
    "auth": 600,
}
OUTCOME_LABEL = {"ok": "ok", "notfound": "no data", "ratelimited": "rate limit",
                 "auth": "key rejected", "error": "unreachable", "cooldown": "paused"}
OUTCOME_MESSAGE = {
    "notfound": "No provider has data for this BIN.",
    "ratelimited": "Provider rate limit reached. Try again shortly.",
    "auth": "An API key was rejected. Check the keys in Settings.",
    "cooldown": "Providers are paused after recent failures. Try again in a minute.",
    "error": "Could not reach the data providers (offline?).",
}


def default_data_dir() -> str:
    """Writable app storage (FLET_APP_STORAGE_DATA on Android)."""
    base = os.environ.get("FLET_APP_STORAGE_DATA") or os.path.join(
        os.path.expanduser("~"), ".bin_atlas")
    os.makedirs(base, exist_ok=True)
    return base


# ----------------------------------------------------------------------
# Pure helpers
# ----------------------------------------------------------------------
def extract_bins(text: str, limit: int = 20) -> list[str]:
    """Unique 6-digit BINs from free text (comma / Arabic comma / ; / newline,
    or space-separated groups when each group has >= 6 digits)."""
    out: list[str] = []
    for token in re.split(r"[,\u060c;\n]+", text or ""):
        parts = token.split()
        if len(parts) > 1 and all(len(re.sub(r"\D", "", p)) >= 6 for p in parts):
            candidates = parts
        else:
            candidates = [token]
        for cand in candidates:
            digits = re.sub(r"\D", "", cand)
            if len(digits) >= 6 and digits[:6] not in out:
                out.append(digits[:6])
    return out[:limit]


def had_extra_digits(text: str) -> bool:
    for token in re.split(r"[,\u060c;\n]+", text or ""):
        parts = token.split()
        if len(parts) > 1 and all(len(re.sub(r"\D", "", p)) >= 6 for p in parts):
            if any(len(re.sub(r"\D", "", p)) > 8 for p in parts):
                return True
        elif len(re.sub(r"\D", "", token)) > 8:
            return True
    return False


def flag_emoji(country_code: str) -> str:
    if not country_code or len(country_code) != 2 or not country_code.isalpha():
        return "\U0001F310"
    return "".join(chr(127397 + ord(c)) for c in country_code.upper())


def detect_scheme(prefix: str) -> tuple[str, str]:
    """Guess the card network from leading digits (offline fallback)."""
    p = re.sub(r"\D", "", prefix or "")
    if not p:
        return "UNKNOWN", ""

    def in_range(k: int, lo: int, hi: int) -> bool:
        return len(p) >= k and lo <= int(p[:k]) <= hi

    if p[:2] in ("34", "37"):
        return "AMEX", "15"
    if in_range(4, 3528, 3589):
        return "JCB", "16-19"
    if in_range(3, 300, 305) or p[:2] in ("36", "38", "39"):
        return "DINERS CLUB", "14-19"
    if p.startswith("6011") or in_range(3, 644, 649) or p.startswith("65"):
        return "DISCOVER", "16-19"
    if p.startswith("62"):
        return "UNIONPAY", "16-19"
    if in_range(4, 2200, 2204):
        return "MIR", "16-19"
    if p[:2] in ("51", "52", "53", "54", "55") or in_range(4, 2221, 2720):
        return "MASTERCARD", "16"
    if p.startswith(("5018", "5020", "5038", "5893", "6304", "6759",
                     "6761", "6762", "6763")):
        return "MAESTRO", "12-19"
    if p.startswith("4"):
        return "VISA", "13, 16 or 19"
    return "UNKNOWN", ""


LENGTHS = {
    "VISA": {13, 16, 19}, "MASTERCARD": {16}, "AMEX": {15},
    "DINERS CLUB": set(range(14, 20)), "DISCOVER": set(range(16, 20)),
    "JCB": set(range(16, 20)), "UNIONPAY": set(range(16, 20)),
    "MIR": set(range(16, 20)), "MAESTRO": set(range(12, 20)),
}


def length_ok(scheme: str, n: int):
    """True/False if the length is plausible for the network, None if unknown."""
    allowed = LENGTHS.get(scheme)
    return None if allowed is None else n in allowed


def luhn_steps(number: str):
    """Explain the Luhn checksum step by step (education only)."""
    digits = [int(c) for c in re.sub(r"\D", "", number or "")]
    if len(digits) < 2:
        return None
    steps, total = [], 0
    for idx, d in enumerate(reversed(digits)):
        doubled = idx % 2 == 1
        value = d * 2 if doubled else d
        if value > 9:
            value -= 9
        total += value
        steps.append({"digit": d, "doubled": doubled, "value": value})
    steps.reverse()
    return {"steps": steps, "total": total, "valid": total % 10 == 0}


def mask_number(digits: str) -> str:
    """Card-length numbers are shown as first 6 + last 4; short examples in full."""
    n = len(digits)
    if n < 13:
        return digits
    return digits[:6] + "\u2022" * (n - 10) + digits[-4:]


def luhn_batch(text: str, limit: int = 25) -> dict:
    """Check several numbers at once. Pure checksum, on-device, nothing stored."""
    tokens = [t for t in re.split(r"[,\n;\u060c]+", text or "") if t.strip()]
    truncated = len(tokens) > limit
    items = []
    for i, tok in enumerate(tokens[:limit], 1):
        digits = re.sub(r"\D", "", tok)
        item = {"index": i, "digits": digits, "masked": mask_number(digits),
                "length": len(digits), "valid": None, "scheme": "UNKNOWN",
                "length_ok": None, "error": "", "total": None}
        if len(digits) < 2:
            item["error"] = "Too short"
        elif len(digits) > 19:
            item["error"] = "Longer than 19 digits"
        else:
            res = luhn_steps(digits)
            item["valid"], item["total"] = res["valid"], res["total"]
            item["scheme"] = detect_scheme(digits)[0]
            item["length_ok"] = length_ok(item["scheme"], len(digits))
        items.append(item)
    return {"items": items, "truncated": truncated,
            "passed": sum(1 for x in items if x["valid"] is True),
            "failed": sum(1 for x in items if x["valid"] is False)}


def _up(v, default="N/A") -> str:
    s = str(v).strip() if v not in (None, "") else ""
    return s.upper() if s else default


def _txt(v, default="N/A") -> str:
    s = str(v).strip() if v not in (None, "") else ""
    return s or default


def _yn(v, default="Unknown") -> str:
    return "Yes" if v is True else ("No" if v is False else default)


def _is_na(v) -> bool:
    return v in NA_VALUES


# ----------------------------------------------------------------------
# Engine
# ----------------------------------------------------------------------
class BinEngine:
    def __init__(self, db_path: str | None = None):
        self.db_path = db_path or os.path.join(default_data_dir(), "bin_atlas.db")
        self._cool: dict[str, float] = {}
        self._cool_reason: dict[str, str] = {}
        self._init_db()

    # -- storage -------------------------------------------------------
    def _q(self, sql: str, params=(), one: bool = False):
        with closing(sqlite3.connect(self.db_path, timeout=10)) as conn:
            conn.row_factory = sqlite3.Row
            cur = conn.execute(sql, params)
            result = cur.fetchone() if one else cur.fetchall()
            conn.commit()
        if one:
            return dict(result) if result else None
        return [dict(r) for r in result]

    def _init_db(self):
        cols = ",".join(f"{n} {ddl}" for n, ddl in SCHEMA_COLUMNS)
        self._q(f"CREATE TABLE IF NOT EXISTS bins ({cols})")
        # Migration: databases created by v1 lack the newer columns.
        have = {r["name"] for r in self._q("PRAGMA table_info(bins)")}
        for name, ddl in SCHEMA_COLUMNS:
            if name not in have:
                self._q(f"ALTER TABLE bins ADD COLUMN {name} {ddl}")
        self._q("CREATE TABLE IF NOT EXISTS misses (bin TEXT PRIMARY KEY, ts TEXT)")
        self._q("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT)")
        self._q("CREATE INDEX IF NOT EXISTS idx_bins_country ON bins(country_code)")
        self._q("CREATE INDEX IF NOT EXISTS idx_bins_bank ON bins(bank)")
        self._q("CREATE INDEX IF NOT EXISTS idx_bins_seen ON bins(looked_up_at)")
        if self._q("SELECT COUNT(*) AS n FROM bins", one=True)["n"] == 0:
            # Small bundled sample so the app is usable offline on first run.
            # Illustrative and UNVERIFIED; live data replaces it.
            seed = [
                ("440393", "VISA", "DEBIT", "PREPAID CLASSIC", "SUTTON BANK", "UNITED STATES", "US", "USD"),
                ("405542", "VISA", "CREDIT", "CLASSIC", "PT. BANK DBS INDONESIA", "INDONESIA", "ID", "IDR"),
                ("408353", "VISA", "DEBIT", "CLASSIC", "JPMORGAN CHASE BANK, N.A.", "UNITED STATES", "US", "USD"),
                ("424242", "VISA", "CREDIT", "CLASSIC", "STRIPE TEST BANK", "UNITED STATES", "US", "USD"),
                ("510510", "MASTERCARD", "CREDIT", "STANDARD", "MASTERCARD TEST ISSUER", "UNITED STATES", "US", "USD"),
                ("378282", "AMEX", "CREDIT", "CORPORATE", "AMERICAN EXPRESS COMPANY", "UNITED STATES", "US", "USD"),
                ("526412", "MASTERCARD", "DEBIT", "PLATINUM", "AL RAJHI BANK", "SAUDI ARABIA", "SA", "SAR"),
            ]
            with closing(sqlite3.connect(self.db_path)) as conn:
                for b, scheme, typ, brand, bank, country, cc, cur in seed:
                    conn.execute(
                        "INSERT OR IGNORE INTO bins (bin,scheme,type,brand,bank,country,country_code,currency,source) "
                        "VALUES (?,?,?,?,?,?,?,?,?)",
                        (b, scheme, typ, brand, bank, country, cc, cur, SAMPLE_SOURCE))
                conn.commit()

    @staticmethod
    def _now() -> str:
        return datetime.now().strftime(TS_FMT)

    def count(self) -> int:
        return self._q("SELECT COUNT(*) AS n FROM bins", one=True)["n"]

    # -- settings / keys ----------------------------------------------
    def get_setting(self, key: str, default: str = "") -> str:
        row = self._q("SELECT value FROM settings WHERE key=?", (key,), one=True)
        return row["value"] if row and row["value"] is not None else default

    def set_setting(self, key: str, value: str):
        self._q("INSERT OR REPLACE INTO settings (key, value) VALUES (?,?)", (key, value))

    def set_api_keys(self, handyapi: str = "", binlistio: str = "") -> list[str]:
        """Validate and store keys. Returns a list of problems (empty = saved)."""
        handyapi, binlistio = (handyapi or "").strip(), (binlistio or "").strip()
        problems = []
        if handyapi.upper().startswith("HAS-"):
            problems.append("That HandyAPI key is the SECRET key (HAS-...). A mobile app "
                            "must only use the publishable key (PUB-...).")
        for label, key in (("HandyAPI", handyapi), ("binlist.io", binlistio)):
            if re.search(r"\s", key):
                problems.append(f"The {label} key contains spaces. Paste it again.")
        if problems:
            return problems
        self.set_setting("handyapi_key", handyapi)
        self.set_setting("binlistio_key", binlistio)
        self._cool.clear()
        return []

    def has_keys(self) -> bool:
        return bool(self.get_setting("handyapi_key") or self.get_setting("binlistio_key"))

    # -- providers ----------------------------------------------------
    def _get_json(self, url: str, headers: dict | None = None):
        hdr = {"User-Agent": USER_AGENT, "Accept": "application/json"}
        hdr.update(headers or {})
        try:
            r = requests.get(url, headers=hdr, timeout=HTTP_TIMEOUT)
        except requests.RequestException:
            return None, "error"
        if r.status_code == 404:
            return None, "notfound"
        if r.status_code == 429:
            return None, "ratelimited"
        if r.status_code in (401, 403):
            return None, "auth"
        if r.status_code != 200:
            return None, "error"
        try:
            return r.json(), "ok"
        except ValueError:
            return None, "error"

    @staticmethod
    def _from_binlist_shape(b: str, d: dict, source: str):
        """Shared mapper: binlist.net and binlist.io use the same JSON layout.
        `or {}` is deliberate: these APIs return "bank": null for many BINs."""
        bank = d.get("bank") or {}
        if not isinstance(bank, dict):
            bank = {"name": bank}
        country = d.get("country") or {}
        if not isinstance(country, dict):
            country = {"name": country}
        number = d.get("number") or {}
        brand = _up(d.get("brand"))
        rec = {
            "bin": b, "source": source,
            "scheme": _up(d.get("scheme")), "type": _up(d.get("type")), "brand": brand,
            "bank": _up(bank.get("name")), "phone": _txt(bank.get("phone")),
            "url": _txt(bank.get("url")),
            "country": _up(country.get("name")),
            "country_code": _up(country.get("alpha2"), ""),
            "country_a3": _up(country.get("alpha3")),
            "continent": "N/A", "dial_code": "N/A",
            "currency": _up(country.get("currency")),
            "prepaid": _yn(d.get("prepaid")),
            "commercial": "Yes" if any(k in brand for k in COMMERCIAL_WORDS) else "Unknown",
            "luhn": _yn(number.get("luhn") if isinstance(number, dict) else None, "N/A"),
        }
        useful = any(not _is_na(rec[f]) for f in ("scheme", "type", "bank", "country"))
        return rec if useful else None

    def _binlistio(self, b: str):
        key = self.get_setting("binlistio_key")
        d, outcome = self._get_json(f"https://binlist.io/lookup/{b}/",
                                    {"X-API-Key": key} if key else None)
        if outcome != "ok":
            return None, outcome
        if not isinstance(d, dict):
            return None, "error"
        if d.get("success") is False:
            return None, "notfound"
        rec = self._from_binlist_shape(b, d, "binlist.io")
        return (rec, "ok") if rec else (None, "error")

    def _handyapi(self, b: str):
        key = self.get_setting("handyapi_key")
        d, outcome = self._get_json(f"https://data.handyapi.com/bin/{b}",
                                    {"x-api-key": key} if key else None)
        if outcome != "ok":
            return None, outcome
        if not isinstance(d, dict):
            return None, "error"
        status = str(d.get("Status", "")).upper()
        if status != "SUCCESS":
            # Only an explicit "not found" counts as a miss; anything else
            # (demo limit, server hiccup) must not poison the cache.
            return None, ("notfound" if "NOT" in status and "FOUND" in status else "error")
        country = d.get("Country") or {}
        tier = _up(d.get("CardTier"))
        isd = str(country.get("ISD") or "").strip()
        return {
            "bin": b, "source": "handyapi",
            "scheme": _up(d.get("Scheme")), "type": _up(d.get("Type")), "brand": tier,
            "bank": _up(d.get("Issuer")), "phone": "N/A", "url": "N/A",
            "country": _up(country.get("Name")), "country_code": _up(country.get("A2"), ""),
            "country_a3": _up(country.get("A3")), "continent": _up(country.get("Cont")),
            "dial_code": f"+{isd}" if isd else "N/A",   # ISD is the phone dialing code
            "currency": "N/A",
            "prepaid": "Yes" if "PREPAID" in tier else "Unknown",
            "commercial": "Yes" if any(k in tier for k in COMMERCIAL_WORDS) else "Unknown",
            "luhn": _yn(d.get("Luhn"), "N/A"),
        }, "ok"

    def _binlistnet(self, b: str):
        d, outcome = self._get_json(f"https://lookup.binlist.net/{b}", {"Accept-Version": "3"})
        if outcome != "ok":
            return None, outcome
        rec = self._from_binlist_shape(b, d, "binlist.net") if isinstance(d, dict) else None
        return (rec, "ok") if rec else (None, "error")

    def _providers(self):
        return [("binlist.io", self._binlistio), ("handyapi", self._handyapi),
                ("binlist.net", self._binlistnet)]

    # failover bookkeeping
    def _cooling(self, name: str) -> bool:
        return self._cool.get(name, 0) > time.time()

    def _penalize(self, name: str, outcome: str):
        if outcome == "ratelimited":
            secs = COOLDOWN_SECONDS["ratelimited"].get(name, 60)
        elif outcome in ("auth", "error"):
            secs = COOLDOWN_SECONDS[outcome]
        else:
            return
        self._cool[name] = time.time() + secs
        self._cool_reason[name] = outcome

    @staticmethod
    def _merge(base: dict, extra: dict) -> dict:
        out = dict(base)
        for f in FIELDS:
            if _is_na(out.get(f)) and not _is_na(extra.get(f)):
                out[f] = extra[f]
        out["source"] = f"{base['source']} + {extra['source']}"
        return out

    @staticmethod
    def _needs_fill(rec: dict) -> bool:
        return any(_is_na(rec.get(f)) for f in ("type", "bank", "brand"))

    def _fetch_online(self, b: str):
        """Try providers in order. Returns (record | None, outcome, trail)."""
        combine = self.get_setting("combine", "1") == "1"
        rec, trail = None, []
        for name, fn in self._providers():
            if self._cooling(name):
                trail.append((name, "cooldown"))
                continue
            got, outcome = fn(b)
            trail.append((name, outcome))
            if outcome == "ok":
                rec = got if rec is None else self._merge(rec, got)
                if rec is not got or not (combine and self._needs_fill(rec)):
                    break                      # done (or second source already merged)
            else:
                self._penalize(name, outcome)
        if rec:
            return rec, "ok", trail
        outcomes = [o for _, o in trail]
        for pick in ("notfound", "ratelimited", "auth"):
            if pick in outcomes:
                return None, pick, trail
        if outcomes and all(o == "cooldown" for o in outcomes):
            # Keep the *real* cause (offline / rate limit / bad key) instead of a vague "paused".
            reasons = [self._cool_reason.get(n) for n, _ in trail]
            for pick in ("ratelimited", "auth"):
                if pick in reasons:
                    return None, pick, trail
        return None, "error", trail

    @staticmethod
    def _trail_text(trail) -> str:
        return "  \u2192  ".join(f"{n}: {OUTCOME_LABEL.get(o, o)}" for n, o in trail)

    def test_providers(self) -> dict:
        """Connectivity/key check for Settings. Uses a public test BIN."""
        out = {}
        for name, fn in self._providers():
            rec, outcome = fn("424242")
            ok = outcome == "ok"
            if ok:
                self._cool.pop(name, None)
            out[name] = (ok, "working" if ok else OUTCOME_LABEL.get(outcome, outcome))
        return out

    # -- cache logic --------------------------------------------------
    def _is_fresh(self, row: dict) -> bool:
        if row.get("source") == SAMPLE_SOURCE or not row.get("fetched_at"):
            return False
        try:
            age = datetime.now() - datetime.strptime(row["fetched_at"], TS_FMT)
        except ValueError:
            return False
        return age < timedelta(days=CACHE_TTL_DAYS)

    def _recent_miss(self, b: str) -> bool:
        row = self._q("SELECT ts FROM misses WHERE bin=?", (b,), one=True)
        if not row:
            return False
        try:
            return datetime.now() - datetime.strptime(row["ts"], TS_FMT) < timedelta(hours=NEG_CACHE_HOURS)
        except ValueError:
            return False

    def _upsert(self, rec: dict):
        b = rec["bin"]
        values = [rec.get(f, "N/A") for f in FIELDS]
        if self._q("SELECT 1 AS x FROM bins WHERE bin=?", (b,), one=True):
            self._q("UPDATE bins SET " + ",".join(f"{f}=?" for f in FIELDS) +
                    ",source=?,fetched_at=? WHERE bin=?",
                    values + [rec["source"], self._now(), b])
        else:
            self._q("INSERT INTO bins (bin," + ",".join(FIELDS) + ",source,fetched_at) VALUES (?" +
                    ",?" * (len(FIELDS) + 2) + ")", [b] + values + [rec["source"], self._now()])
        self._q("DELETE FROM misses WHERE bin=?", (b,))

    def _row_to_result(self, row: dict, status: str, message: str, trail: str = "") -> dict:
        scheme, lengths = detect_scheme(row["bin"])
        res = dict(row)
        for f in FIELDS:
            if res.get(f) is None:
                res[f] = "N/A"
        res.update({"found": True, "status": status, "message": message, "trail": trail,
                    "flag": flag_emoji(row.get("country_code", "")),
                    "detected_scheme": scheme, "expected_length": lengths,
                    "note": row.get("note") or "", "favorite": int(row.get("favorite") or 0)})
        return res

    def _status_of(self, row: dict) -> str:
        if row["source"] == SAMPLE_SOURCE:
            return "sample"
        return "cached" if self._is_fresh(row) else "stale"

    # -- public lookup API --------------------------------------------
    def lookup(self, bin_code: str, allow_network: bool = True, force_refresh: bool = False) -> dict:
        b = re.sub(r"\D", "", bin_code or "")[:6]       # privacy: drop everything past 6 digits
        scheme, lengths = detect_scheme(b)
        result = {"bin": b, "found": False, "status": "", "message": "", "trail": "",
                  "detected_scheme": scheme, "expected_length": lengths, "flag": flag_emoji("")}
        if len(b) < 6:
            result["message"] = "Enter at least 6 digits."
            return result

        row = self._q("SELECT * FROM bins WHERE bin=?", (b,), one=True)
        need_net = allow_network and (force_refresh or row is None or not self._is_fresh(row))
        message, trail_text, fetched_live = "", "", False

        if need_net and not force_refresh and self._recent_miss(b):
            need_net = False
            message = "No provider had data for this BIN in the last 24 hours."

        if need_net:
            rec, outcome, trail = self._fetch_online(b)
            trail_text = self._trail_text(trail)
            if rec:
                self._upsert(rec)
                row = self._q("SELECT * FROM bins WHERE bin=?", (b,), one=True)
                fetched_live = True
            else:
                message = OUTCOME_MESSAGE.get(outcome, "No data found.")
                tried = [o for _, o in trail if o != "cooldown"]
                if tried and all(o == "notfound" for o in tried):    # every asked provider said "unknown"
                    self._q("INSERT OR REPLACE INTO misses (bin, ts) VALUES (?,?)", (b, self._now()))
        elif not allow_network:
            message = "Offline mode: showing local data only."

        if row:
            self._q("UPDATE bins SET looked_up_at=?, lookup_count=COALESCE(lookup_count,0)+1 WHERE bin=?",
                    (self._now(), b))
            row = self._q("SELECT * FROM bins WHERE bin=?", (b,), one=True)
            status = "live" if fetched_live else self._status_of(row)
            return self._row_to_result(row, status, message, trail_text)
        result["message"] = message or "No data found."
        result["trail"] = trail_text
        return result

    def get_record(self, bin_code: str) -> dict:
        """Stored record without network access or history side-effects."""
        b = re.sub(r"\D", "", bin_code or "")[:6]
        row = self._q("SELECT * FROM bins WHERE bin=?", (b,), one=True)
        if not row:
            scheme, lengths = detect_scheme(b)
            return {"bin": b, "found": False, "status": "", "message": "Not stored on this device.",
                    "trail": "", "detected_scheme": scheme, "expected_length": lengths,
                    "flag": flag_emoji("")}
        return self._row_to_result(row, self._status_of(row), "")

    # -- saved / notes ------------------------------------------------
    def save_bin(self, b: str, note: str = "") -> bool:
        if not self._q("SELECT 1 AS x FROM bins WHERE bin=?", (b,), one=True):
            return False
        self._q("UPDATE bins SET favorite=1, note=?, saved_at=COALESCE(saved_at, ?) WHERE bin=?",
                ((note or "").strip(), self._now(), b))
        return True

    def unsave_bin(self, b: str):
        self._q("UPDATE bins SET favorite=0, note='', saved_at=NULL WHERE bin=?", (b,))

    def saved(self, query: str = "") -> list[dict]:
        sql, p = "SELECT * FROM bins WHERE favorite=1", []
        if query.strip():
            like = self._like(query)
            sql += (" AND (bin LIKE ? OR UPPER(bank) LIKE ? OR UPPER(note) LIKE ? "
                    "OR UPPER(country) LIKE ? OR UPPER(scheme) LIKE ?)")
            p += [like] * 5
        return self._q(sql + " ORDER BY saved_at DESC, bin", p)

    def history(self, limit: int = 40) -> list[dict]:
        return self._q("SELECT * FROM bins WHERE looked_up_at IS NOT NULL "
                       "ORDER BY looked_up_at DESC LIMIT ?", (limit,))

    def clear_history(self):
        self._q("UPDATE bins SET looked_up_at=NULL, lookup_count=0")

    # -- search / cascading filters -----------------------------------
    @staticmethod
    def _like(s: str) -> str:
        return "%" + re.sub(r"[%_]", " ", s.strip().upper()) + "%"

    def _distinct(self, col: str, where: dict) -> list[str]:
        assert col in FILTER_COLUMNS
        sql = (f"SELECT DISTINCT {col} AS v FROM bins WHERE {col} IS NOT NULL "
               f"AND {col} NOT IN ('', 'N/A', 'UNKNOWN')")
        params = []
        for c, v in where.items():
            if v:
                assert c in FILTER_COLUMNS
                sql += f" AND {c}=?"
                params.append(v)
        return [r["v"] for r in self._q(sql + f" ORDER BY {col}", params)]

    def facets(self, country: str = "", scheme: str = "", bank: str = "", type_: str = "") -> dict:
        """Options for bincheck.io-style cascading filters:
        Country -> Brand(network) -> Bank -> Type -> Level. Each list depends on
        the selections to its left."""
        countries = self._q("SELECT DISTINCT country_code AS cc, country AS name FROM bins "
                            "WHERE country_code NOT IN ('', 'N/A') ORDER BY name")
        return {
            "countries": [(r["cc"], r["name"]) for r in countries],
            "schemes": self._distinct("scheme", {"country_code": country}),
            "banks": self._distinct("bank", {"country_code": country, "scheme": scheme}),
            "types": self._distinct("type", {"country_code": country, "scheme": scheme, "bank": bank}),
            "levels": self._distinct("brand", {"country_code": country, "scheme": scheme,
                                               "bank": bank, "type": type_}),
        }

    def search_filters(self, country: str = "", scheme: str = "", bank: str = "",
                       type_: str = "", level: str = "", limit: int = 300) -> list[dict]:
        sql, p = "SELECT * FROM bins WHERE 1=1", []
        for col, val in (("country_code", country), ("scheme", scheme), ("bank", bank),
                         ("type", type_), ("brand", level)):
            if val:
                sql += f" AND {col}=?"
                p.append(val)
        return self._q(sql + " ORDER BY bank, bin LIMIT ?", p + [limit])

    def search(self, bank: str = "", text: str = "", country: str = "", limit: int = 100) -> list[dict]:
        sql, p = "SELECT * FROM bins WHERE 1=1", []
        if bank.strip():
            sql += " AND UPPER(bank) LIKE ?"
            p.append(self._like(bank))
        if text.strip():
            sql += " AND (UPPER(scheme) LIKE ? OR UPPER(brand) LIKE ? OR UPPER(type) LIKE ?)"
            p += [self._like(text)] * 3
        if country.strip():
            sql += " AND (UPPER(country_code) LIKE ? OR UPPER(country) LIKE ?)"
            p += [self._like(country)] * 2
        return self._q(sql + " ORDER BY bank, bin LIMIT ?", p + [limit])

    # -- CSV import (public BIN lists) --------------------------------
    HEADER_ALIASES = {
        "bin": ("bin", "iin", "bin_iin"),
        "scheme": ("scheme", "brand", "network", "card_brand", "cardscheme"),
        "type": ("type", "card_type", "cardtype"),
        "brand": ("category", "level", "tier", "cardtier", "card_level", "product"),
        "bank": ("issuer", "bank", "bank_name", "issuer_name"),
        "phone": ("issuerphone", "bank_phone", "phone"),
        "url": ("issuerurl", "bank_url", "url", "website"),
        "country_code": ("isocode2", "country_code", "alpha2", "a2", "country_iso"),
        "country_a3": ("isocode3", "alpha3", "a3"),
        "country": ("countryname", "country", "country_name"),
    }

    def _map_headers(self, headers: dict) -> dict:
        mapping, used = {}, set()
        for field, aliases in self.HEADER_ALIASES.items():
            for a in aliases:
                if a in headers and headers[a] not in used:
                    mapping[field] = headers[a]
                    used.add(headers[a])
                    break
        return mapping

    @staticmethod
    def _clean_field(field: str, raw) -> str:
        if field in ("phone", "url"):
            return _txt(raw)
        if field == "country_code":
            return _up(raw, "")
        if field in ("prepaid", "commercial"):
            return "Unknown"
        return _up(raw)

    def import_csv(self, path: str) -> dict:
        """Import a public BIN list. Existing (live) rows are never overwritten."""
        with open(path, newline="", encoding="utf-8-sig", errors="replace") as f:
            reader = csv.DictReader(f)
            if not reader.fieldnames:
                raise ValueError("The CSV file is empty.")
            headers = {h.strip().lower(): h for h in reader.fieldnames if h}
            mapping = self._map_headers(headers)
            if "bin" not in mapping:
                raise ValueError("The CSV needs a BIN or IIN column.")
            cols = ["bin"] + FIELDS + ["source", "fetched_at"]
            sql = f"INSERT OR IGNORE INTO bins ({','.join(cols)}) VALUES ({','.join('?' * len(cols))})"
            total, batch, now = 0, [], self._now()
            with closing(sqlite3.connect(self.db_path, timeout=30)) as conn:
                before = conn.total_changes
                for row in reader:
                    total += 1
                    digits = re.sub(r"\D", "", row.get(mapping["bin"]) or "")[:6]
                    if len(digits) < 6:
                        continue
                    vals = [digits]
                    for fld in FIELDS:
                        vals.append(self._clean_field(fld, row.get(mapping[fld]) if fld in mapping else ""))
                    batch.append(vals + ["Imported CSV", now])
                    if len(batch) >= 5000:
                        conn.executemany(sql, batch)
                        batch = []
                if batch:
                    conn.executemany(sql, batch)
                conn.commit()
                added = conn.total_changes - before
        return {"rows": total, "added": added}

    # -- text / export ------------------------------------------------
    @staticmethod
    def format_report(d: dict, note: str = "") -> str:
        lines = [
            f"BIN {d['bin']}",
            f"Scheme: {d['scheme']} | Type: {d['type']} | Tier: {d['brand']}",
            f"Issuer: {d['bank']}",
            f"Country: {d['flag']} {d['country']} ({d['country_code'] or 'N/A'}/{d.get('country_a3', 'N/A')}) "
            f"| Continent: {d.get('continent', 'N/A')} | Dial: {d.get('dial_code', 'N/A')}",
            f"Currency: {d['currency']} | Luhn: {d.get('luhn', 'N/A')}",
            f"Prepaid: {d['prepaid']} | Commercial: {d['commercial']}",
            f"Phone: {d['phone']}  Website: {d['url']}",
            f"Source: {d['source']} ({d['status']})",
        ]
        n = (note or d.get("note") or "").strip()
        if n:
            lines.append(f"Note: {n}")
        return "\n".join(lines)

    @staticmethod
    def to_csv(rows: list[dict]) -> str:
        cols = ["bin", "scheme", "type", "brand", "bank", "country", "country_code", "country_a3",
                "continent", "dial_code", "currency", "luhn", "prepaid", "commercial", "phone",
                "url", "note", "source", "fetched_at"]
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(cols)
        for r in rows:
            w.writerow([r.get(c, "") for c in cols])
        return buf.getvalue()

    def export_csv_file(self, rows: list[dict]) -> tuple[str, str]:
        text = self.to_csv(rows)
        folder = os.path.join(os.path.dirname(self.db_path), "exports")
        os.makedirs(folder, exist_ok=True)
        path = os.path.join(folder, f"bins_{datetime.now():%Y%m%d_%H%M%S}.csv")
        with open(path, "w", encoding="utf-8", newline="") as f:
            f.write(text)
        return path, text
