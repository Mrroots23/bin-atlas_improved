"""Run: python -m unittest test_engine -v   (no network needed)"""
import glob, os, re, sqlite3, tempfile, unittest
from unittest import mock

import requests

import engine as E


def resp(status=200, payload=None):
    m = mock.Mock(status_code=status)
    m.json.return_value = payload if payload is not None else {}
    return m


BINLIST_OK = {"scheme": "visa", "type": "debit", "brand": "Visa Infinite", "prepaid": False,
              "number": {"luhn": True},
              "country": {"name": "Italy", "alpha2": "IT", "alpha3": "ITA", "currency": "EUR"},
              "bank": {"name": "Revolut Bank UAB", "url": "revolut.com", "phone": "+123"}}
HANDY_OK = {"Status": "SUCCESS", "Scheme": "MASTERCARD", "Type": "CREDIT", "Issuer": "COMMONWEALTH BANK",
            "CardTier": "PLATINUM MASTERCARD", "Luhn": True,
            "Country": {"A2": "AU", "A3": "AUS", "N3": "036", "ISD": "61", "Name": "Australia", "Cont": "Oceania"}}


def router(**by_host):
    """Fake requests.get: by_host maps 'binlist.io' / 'handyapi' / 'binlist.net' to a response or exception."""
    calls = []

    def fake(url, headers=None, timeout=None):
        calls.append((url, headers or {}))
        for host, out in by_host.items():
            if host in url:
                if isinstance(out, Exception):
                    raise out
                return out
        raise requests.ConnectionError("unmapped " + url)
    fake.calls = calls
    return fake


class Helpers(unittest.TestCase):
    def test_extract_bins(self):
        self.assertEqual(E.extract_bins("424242, 510510"), ["424242", "510510"])
        self.assertEqual(E.extract_bins("456288,531416,61100072636"), ["456288", "531416", "611000"])
        self.assertEqual(E.extract_bins("424242 510510"), ["424242", "510510"])
        self.assertEqual(E.extract_bins("4242 4242 4242 4242"), ["424242"])
        self.assertEqual(E.extract_bins("12345"), [])
        self.assertEqual(E.extract_bins("424242\u060c 424242"), ["424242"])

    def test_detect_scheme(self):
        cases = {"424242": "VISA", "510510": "MASTERCARD", "222100": "MASTERCARD", "378282": "AMEX",
                 "601100": "DISCOVER", "353011": "JCB", "620000": "UNIONPAY", "220000": "MIR",
                 "300000": "DINERS CLUB", "999999": "UNKNOWN"}
        for b, s in cases.items():
            self.assertEqual(E.detect_scheme(b)[0], s, b)

    def test_luhn(self):
        self.assertTrue(E.luhn_steps("79927398713")["valid"])
        self.assertFalse(E.luhn_steps("79927398710")["valid"])
        self.assertEqual(E.luhn_steps("79927398713")["total"], 70)
        self.assertIsNone(E.luhn_steps("7"))
        self.assertFalse(E.luhn_steps("123456")["valid"])      # v1 bug: short numbers always passed

    def test_luhn_batch(self):
        r = E.luhn_batch("79927398713\n79927398710, 7, 123456789012345678901")
        self.assertEqual((r["passed"], r["failed"]), (1, 1))
        self.assertEqual(r["items"][2]["error"], "Too short")
        self.assertEqual(r["items"][3]["error"], "Longer than 19 digits")
        big = E.luhn_batch(",".join(["79927398713"] * 40))
        self.assertEqual(len(big["items"]), 25); self.assertTrue(big["truncated"])

    def test_masking_and_length(self):
        self.assertEqual(E.mask_number("79927398713"), "79927398713")         # short example shown fully
        m = E.mask_number("4" * 16)
        self.assertEqual(len(m), 16); self.assertTrue(m.startswith("444444")); self.assertIn("\u2022", m)
        self.assertTrue(E.length_ok("AMEX", 15)); self.assertFalse(E.length_ok("AMEX", 16))
        self.assertIsNone(E.length_ok("UNKNOWN", 16))


class Engine(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = os.path.join(self.tmp.name, "t.db")
        self.eng = E.BinEngine(self.path)

    def tearDown(self):
        self.tmp.cleanup()

    # ---- providers & failover ---------------------------------------
    def test_primary_provider_success_and_cache(self):
        fake = router(**{"binlist.io": resp(200, BINLIST_OK)})
        with mock.patch("engine.requests.get", fake):
            r = self.eng.lookup("416598")
            self.assertEqual((r["status"], r["bank"], r["type"], r["brand"]), ("live", "REVOLUT BANK UAB", "DEBIT", "VISA INFINITE"))
            self.assertEqual(r["luhn"], "Yes")
            n = len(fake.calls)
            self.assertEqual(self.eng.lookup("416598")["status"], "cached")
            self.assertEqual(len(fake.calls), n)

    def test_failover_chain(self):
        fake = router(**{"binlist.io": resp(500), "handyapi": resp(200, HANDY_OK), "binlist.net": resp(404)})
        with mock.patch("engine.requests.get", fake):
            r = self.eng.lookup("535316")
        self.assertTrue(r["found"]); self.assertEqual(r["source"], "handyapi")
        self.assertEqual((r["continent"], r["dial_code"], r["country_a3"]), ("OCEANIA", "+61", "AUS"))
        self.assertIn("binlist.io: unreachable", r["trail"]); self.assertIn("handyapi: ok", r["trail"])

    def test_total_outage_still_returns_something(self):
        fake = router()                                           # everything raises ConnectionError
        with mock.patch("engine.requests.get", fake):
            r = self.eng.lookup("408353")                          # bundled sample row
            self.assertTrue(r["found"]); self.assertEqual(r["status"], "sample")
            r2 = self.eng.lookup("457173")                        # unknown BIN: prefix guess
            self.assertFalse(r2["found"]); self.assertEqual(r2["detected_scheme"], "VISA")
            self.assertIn("offline", r2["message"].lower())

    def test_cooldown_skips_failed_provider(self):
        fake = router(**{"binlist.io": requests.ConnectionError(), "handyapi": requests.ConnectionError(),
                         "binlist.net": requests.ConnectionError()})
        with mock.patch("engine.requests.get", fake):
            self.eng.lookup("457173")
            first = len(fake.calls)
            self.eng.lookup("457174")
            self.assertEqual(len(fake.calls), first)              # all paused: no new network calls
            self.assertIn("paused", self.eng.lookup("457175")["trail"])

    def test_merge_fills_gaps_from_second_source(self):
        sparse = dict(BINLIST_OK, type=None, brand=None)
        fake = router(**{"binlist.io": resp(200, sparse), "handyapi": resp(200, HANDY_OK)})
        with mock.patch("engine.requests.get", fake):
            r = self.eng.lookup("535316")
        self.assertEqual(r["type"], "CREDIT"); self.assertEqual(r["brand"], "PLATINUM MASTERCARD")
        self.assertEqual(r["bank"], "REVOLUT BANK UAB"); self.assertIn("+", r["source"])

    def test_combine_off_uses_single_source(self):
        self.eng.set_setting("combine", "0")
        sparse = dict(BINLIST_OK, type=None)
        fake = router(**{"binlist.io": resp(200, sparse), "handyapi": resp(200, HANDY_OK)})
        with mock.patch("engine.requests.get", fake):
            r = self.eng.lookup("535316")
        self.assertEqual(r["source"], "binlist.io"); self.assertEqual(len(fake.calls), 1)

    def test_null_bank_and_rate_limit_and_auth(self):
        nullbank = dict(BINLIST_OK, bank=None)
        with mock.patch("engine.requests.get", router(**{"binlist.io": resp(200, nullbank)})):
            self.assertEqual(self.eng.lookup("457173")["bank"], "N/A")
        eng2 = E.BinEngine(os.path.join(self.tmp.name, "b.db"))
        rl = router(**{"binlist.io": resp(429), "handyapi": resp(429), "binlist.net": resp(429)})
        with mock.patch("engine.requests.get", rl):
            self.assertIn("rate limit", eng2.lookup("999991")["message"])
        eng3 = E.BinEngine(os.path.join(self.tmp.name, "c.db"))
        au = router(**{"binlist.io": resp(401), "handyapi": resp(403), "binlist.net": resp(401)})
        with mock.patch("engine.requests.get", au):
            self.assertIn("key", eng3.lookup("999992")["message"].lower())

    def test_negative_cache_only_when_all_agree(self):
        nf = router(**{"binlist.io": resp(404), "handyapi": resp(404), "binlist.net": resp(404)})
        with mock.patch("engine.requests.get", nf):
            self.assertFalse(self.eng.lookup("999999")["found"]); n = len(nf.calls)
            self.eng.lookup("999999"); self.assertEqual(len(nf.calls), n)
        mixed = router(**{"binlist.io": resp(404), "handyapi": resp(500), "binlist.net": resp(500)})
        with mock.patch("engine.requests.get", mixed):
            self.eng.lookup("999998")
        self.assertFalse(self.eng._recent_miss("999998"))        # an erroring provider must not poison the cache

    def test_handyapi_demo_limit_is_not_a_miss(self):
        fake = router(**{"binlist.io": resp(500), "handyapi": resp(200, {"Status": "DEMO LIMIT"}), "binlist.net": resp(500)})
        with mock.patch("engine.requests.get", fake):
            self.eng.lookup("999997")
        self.assertFalse(self.eng._recent_miss("999997"))

    def test_keys_sent_as_headers_and_secret_key_refused(self):
        bad = self.eng.set_api_keys(handyapi="HAS-" + "x" * 20, binlistio="bl_test")
        self.assertTrue(bad and "SECRET" in bad[0]); self.assertFalse(self.eng.has_keys())
        self.assertTrue(self.eng.set_api_keys("bad key", ""))
        self.assertEqual(self.eng.set_api_keys("PUB-" + "y" * 20, "bl_" + "z" * 20), [])
        fake = router(**{"binlist.io": resp(500), "handyapi": resp(200, HANDY_OK)})
        with mock.patch("engine.requests.get", fake):
            self.eng.lookup("535316")
        hdr = {u.split("//")[1].split("/")[0]: h for u, h in fake.calls}
        self.assertEqual(hdr["binlist.io"].get("X-API-Key"), "bl_" + "z" * 20)
        self.assertEqual(hdr["data.handyapi.com"].get("x-api-key"), "PUB-" + "y" * 20)

    def test_test_providers(self):
        fake = router(**{"binlist.io": resp(200, BINLIST_OK), "handyapi": resp(401), "binlist.net": resp(429)})
        with mock.patch("engine.requests.get", fake):
            out = self.eng.test_providers()
        self.assertEqual(out["binlist.io"], (True, "working"))
        self.assertEqual(out["handyapi"], (False, "key rejected"))
        self.assertEqual(out["binlist.net"], (False, "rate limit"))

    # ---- saved / notes / history ------------------------------------
    def test_save_with_note_and_find_it(self):
        self.assertFalse(self.eng.save_bin("000000", "x"))        # unknown BIN can't be saved
        self.assertTrue(self.eng.save_bin("408353", "  client Chase card  "))
        rec = self.eng.get_record("408353")
        self.assertEqual((rec["favorite"], rec["note"]), (1, "client Chase card"))
        self.assertEqual([r["bin"] for r in self.eng.saved("chase")], ["408353"])
        self.assertEqual([r["bin"] for r in self.eng.saved("CLIENT")], ["408353"])   # searches the note
        self.assertEqual(self.eng.saved("nomatch"), [])
        self.eng.save_bin("408353", "updated note")
        self.assertEqual(self.eng.get_record("408353")["note"], "updated note")
        self.eng.unsave_bin("408353")
        self.assertEqual((self.eng.get_record("408353")["favorite"], self.eng.get_record("408353")["note"]), (0, ""))

    def test_get_record_has_no_side_effects(self):
        self.eng.get_record("408353"); self.assertEqual(self.eng.history(), [])
        self.eng.lookup("408353", allow_network=False); self.assertEqual(len(self.eng.history()), 1)
        self.eng.clear_history(); self.assertEqual(self.eng.history(), [])

    def test_only_six_digits_stored(self):
        self.eng.lookup("4242424242424242", allow_network=False)
        dump = " ".join(str(v) for r in self.eng._q("SELECT * FROM bins") for v in r.values())
        self.assertNotIn("4242424242", dump)

    # ---- cascading filters (bincheck.io style) -----------------------
    def test_cascading_facets(self):
        f = self.eng.facets()
        self.assertIn(("US", "UNITED STATES"), f["countries"]); self.assertIn(("SA", "SAUDI ARABIA"), f["countries"])
        us = self.eng.facets(country="US")
        self.assertEqual(sorted(us["schemes"]), ["AMEX", "MASTERCARD", "VISA"])
        self.assertNotIn("AL RAJHI BANK", us["banks"])            # banks follow the selected country
        self.assertIn("JPMORGAN CHASE BANK, N.A.", us["banks"])
        v = self.eng.facets(country="US", scheme="VISA", bank="JPMORGAN CHASE BANK, N.A.")
        self.assertEqual(v["types"], ["DEBIT"]); self.assertEqual(v["levels"], ["CLASSIC"])
        rows = self.eng.search_filters(country="US", scheme="VISA", type_="CREDIT")
        self.assertEqual(sorted(r["bin"] for r in rows), ["424242"])
        self.assertEqual(len(self.eng.search_filters()), 7)

    # ---- migration & import & export --------------------------------
    def test_migrates_v1_database(self):
        old = os.path.join(self.tmp.name, "old.db")
        conn = sqlite3.connect(old)
        conn.execute("CREATE TABLE bins (bin TEXT PRIMARY KEY, scheme TEXT, type TEXT, brand TEXT, bank TEXT, phone TEXT, "
                     "url TEXT, country TEXT, country_code TEXT, currency TEXT, prepaid TEXT, commercial TEXT, source TEXT, "
                     "fetched_at TEXT, looked_up_at TEXT, lookup_count INTEGER DEFAULT 0, favorite INTEGER DEFAULT 0)")
        conn.execute("INSERT INTO bins (bin,scheme,type,bank,country_code,favorite,source) VALUES ('416598','VISA','DEBIT','REVOLUT','IT',1,'binlist.net')")
        conn.commit(); conn.close()
        eng = E.BinEngine(old)
        rec = eng.get_record("416598")
        self.assertTrue(rec["found"]); self.assertEqual((rec["favorite"], rec["note"], rec["continent"]), (1, "", "N/A"))
        self.assertTrue(eng.save_bin("416598", "kept after upgrade"))

    def test_csv_import_maps_public_list_headers(self):
        p = os.path.join(self.tmp.name, "bins.csv")
        with open(p, "w", encoding="utf-8") as fh: fh.write(
            "BIN,Brand,Type,Category,Issuer,IssuerPhone,IssuerUrl,isoCode2,isoCode3,CountryName\n"
            "457173,VISA,DEBIT,CLASSIC,JYSKE BANK,+4589893300,www.jyskebank.dk,DK,DNK,DENMARK\n"
            "12345,VISA,DEBIT,X,BAD,,,DK,DNK,DENMARK\n"
            "424242,VISA,DEBIT,X,SHOULD NOT OVERWRITE,,,US,USA,UNITED STATES\n")
        r = self.eng.import_csv(p)
        self.assertEqual(r, {"rows": 3, "added": 1})
        d = self.eng.get_record("457173")
        self.assertEqual((d["bank"], d["brand"], d["country_a3"]), ("JYSKE BANK", "CLASSIC", "DNK"))
        self.assertEqual(self.eng.get_record("424242")["bank"], "STRIPE TEST BANK")
        self.assertIn(("DK", "DENMARK"), self.eng.facets()["countries"])
        bad = os.path.join(self.tmp.name, "bad.csv")
        with open(bad, "w") as fh: fh.write("foo,bar\n1,2\n")
        with self.assertRaises(ValueError): self.eng.import_csv(bad)

    def test_csv_export_has_notes(self):
        self.eng.save_bin("408353", "hello, world")
        path, text = self.eng.export_csv_file(self.eng.saved())
        self.assertTrue(os.path.exists(path)); self.assertIn('"hello, world"', text)


class Hygiene(unittest.TestCase):
    def test_no_api_keys_in_source(self):
        """Fails if anyone pastes a real key into the code (it would leak via GitHub / the APK)."""
        pat = re.compile(r"\b(bl_[A-Za-z0-9_\-]{20,}|HAS-[A-Za-z0-9]{10,}|PUB-[A-Za-z0-9]{10,})")
        here = os.path.dirname(os.path.abspath(__file__))
        for f in glob.glob(os.path.join(here, "**", "*.*"), recursive=True):
            if f.endswith((".py", ".md", ".toml", ".yml", ".txt")) and os.path.basename(f) != "test_engine.py":
                with open(f, encoding="utf-8", errors="ignore") as fh:
                    self.assertIsNone(pat.search(fh.read()), f)


if __name__ == "__main__":
    unittest.main()
